# Internet access and economic development project
# Download and clean World Bank panel data.

# Project setup ===========================================================

script_folder <- getwd()

input_folder <- file.path(script_folder, "..", "input")
output_folder <- file.path(script_folder, "..", "output")

# Create folders if they do not already exist
if (!dir.exists(input_folder)) {
  dir.create(input_folder, recursive = TRUE)
}

if (!dir.exists(output_folder)) {
  dir.create(output_folder, recursive = TRUE)
}

# Libraries ===============================================================

library(WDI)          # Download World Bank data
library(tidyverse)    # Data cleaning and plots

# Data ====================================================================

vars <- c(
  gdp_pc     = "NY.GDP.PCAP.PP.KD",
  internet   = "IT.NET.USER.ZS",
  education  = "SE.SEC.ENRR",
  urban      = "SP.URB.TOTL.IN.ZS",
  investment = "NE.GDI.TOTL.ZS"
)

raw_data_path <- file.path(input_folder, "world_bank_raw.csv")
clean_data_path <- file.path(output_folder, "world_bank_clean.csv")

data_raw <- WDI(
  country = "all",
  indicator = vars,
  start = 2005,
  end = 2024,
  extra = TRUE
)

write_csv(data_raw, raw_data_path)

data <- data_raw %>%
  filter(region != "Aggregates") %>%
  select(
    iso2c,
    country,
    year,
    gdp_pc,
    internet,
    education,
    urban,
    investment
  ) %>%
  mutate(
    year = as.integer(year),
    log_gdp_pc = log(gdp_pc)
  ) %>%
  drop_na()

write_csv(data, clean_data_path)

# Inspect data ============================================================

glimpse(data)

summary(data)
