# Internet access and economic development project
# Analyze the cleaned World Bank panel data.

# Project setup ===========================================================

script_folder <- getwd()

output_folder <- file.path(script_folder, "output")
figures_folder <- file.path(output_folder, "figures")
tables_folder <- file.path(output_folder, "tables")

# Create folders if they do not already exist
if (!dir.exists(figures_folder)) {
  dir.create(figures_folder, recursive = TRUE)
}

if (!dir.exists(tables_folder)) {
  dir.create(tables_folder, recursive = TRUE)
}

# Libraries ===============================================================

library(tidyverse)    # Data cleaning and plots
library(fixest)       # OLS and fixed-effects regressions
library(modelsummary) # Regression and summary tables

# Data ====================================================================

clean_data_path <- file.path(output_folder, "world_bank_clean.csv")

data <- read_csv(clean_data_path, show_col_types = FALSE)

# Inspect data ============================================================

glimpse(data)

summary(data)

# Summary statistics ======================================================

summary_table <- datasummary(
  (gdp_pc + log_gdp_pc + internet + education + urban + investment) ~
    Mean + SD + Min + Max + N,
  data = data,
  output = file.path(
    tables_folder,
    "summary_statistics.tex"
  )
)

summary_table

# Figures ================================================================

internet_gdp_plot <- ggplot(
  data,
  aes(
    x = internet,
    y = log_gdp_pc
  )
) +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm") +
  labs(
    title = "Internet access and economic development",
    subtitle = "Country-year observations, 2005-2024",
    x = "Internet users (% population)",
    y = "Log GDP per capita"
  )

internet_gdp_plot

ggsave(
  filename = file.path(figures_folder, "internet_gdp_plot.png"),
  plot = internet_gdp_plot,
  width = 8,
  height = 6
)

# Regressions ============================================================


# Baseline OLS ------------------------------------------------------------

m1 <- feols(
  log_gdp_pc ~ internet,
  data = data,
  vcov = ~country
)

summary(m1)

# OLS with controls -------------------------------------------------------

m2 <- feols(
  log_gdp_pc ~ internet +
    education +
    urban +
    investment,
  data = data,
  vcov = ~country
)

summary(m2)

# Fixed effects -----------------------------------------------------------

m3 <- feols(
  log_gdp_pc ~ internet +
    education +
    urban +
    investment |
    country,
  data = data,
  vcov = ~country
)

summary(m3)

# Country and year fixed effects ------------------------------------------

m4 <- feols(
  log_gdp_pc ~ internet +
    education +
    urban +
    investment |
    country + year,
  data = data,
  vcov = ~country
)

summary(m4)

# Regression table ========================================================

modelsummary(
  list(
    "Baseline OLS" = m1,
    "Controls" = m2,
    "Country FE" = m3,
    "Country + Year FE" = m4
  ),
  coef_map = c(
    "internet" = "Internet access",
    "education" = "Education",
    "urban" = "Urbanization",
    "investment" = "Investment"
  ),
  gof_map = tibble::tribble(
    ~raw,                ~clean,          ~fmt,
    "nobs",             "Observations", 0,
    "r.squared",        "R²",           3,
    "adj.r.squared",    "Adj. R²",      3,
    "within.r.squared", "Within R²",    3
  ),
  add_rows = tibble::tribble(
    ~term,         ~`Baseline OLS`, ~Controls, ~`Country FE`, ~`Country + Year FE`,
    "Country FE", "No",           "No",    "Yes",        "Yes",
    "Year FE",    "No",           "No",    "No",         "Yes"
  ),
  stars = c(
    "***" = 0.001,
    "**" = 0.01,
    "*" = 0.05,
    "+" = 0.1
  ),
  notes = "Standard errors clustered at the country level are reported in parentheses.",
  output = file.path(
    tables_folder,
    "regression_table.tex"
  )
)
