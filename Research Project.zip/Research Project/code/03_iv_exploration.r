# Internet access and economic development project
# Exploratory instrumental-variable analysis.

# Project setup ===========================================================

script_folder <- getwd()

input_folder <- file.path(script_folder, "input")
output_folder <- file.path(script_folder, "output")
tables_folder <- file.path(output_folder, "tables")

# Create folders if they do not already exist
if (!dir.exists(input_folder)) {
  dir.create(input_folder, recursive = TRUE)
}

if (!dir.exists(output_folder)) {
  dir.create(output_folder, recursive = TRUE)
}

if (!dir.exists(tables_folder)) {
  dir.create(tables_folder, recursive = TRUE)
}

# Libraries ===============================================================

library(WDI)          # Download World Bank data
library(tidyverse)    # Data cleaning
library(fixest)       # IV regressions
library(modelsummary) # Regression tables

# Data ====================================================================

vars_iv <- c(
  gdp_pc     = "NY.GDP.PCAP.PP.KD",
  internet   = "IT.NET.USER.ZS",
  telephone  = "IT.MLT.MAIN.P2",
  education  = "SE.SEC.ENRR",
  urban      = "SP.URB.TOTL.IN.ZS",
  investment = "NE.GDI.TOTL.ZS"
)

raw_data_path <- file.path(input_folder, "iv_world_bank_raw.csv")
clean_data_path <- file.path(output_folder, "iv_world_bank_clean.csv")

data_raw <- WDI(
  country = "all",
  indicator = vars_iv,
  start = 2005,
  end = 2024,
  extra = TRUE
)

write_csv(data_raw, raw_data_path)

data <- data_raw %>%
  filter(region != "Aggregates") %>%
  select(
    iso2c,
    country,
    year,
    gdp_pc,
    internet,
    telephone,
    education,
    urban,
    investment
  ) %>%
  mutate(
    log_gdp_pc = log(gdp_pc)
  ) %>%
  arrange(country, year) %>%
  group_by(country) %>%
  mutate(
    telephone_lag = lag(telephone)
  ) %>%
  ungroup() %>%
  drop_na()

write_csv(data, clean_data_path)

# Exploratory IV regression ===============================================
# Lagged fixed telephone subscriptions are used as an exploratory instrument
# for internet access. The exclusion restriction is debatable, so these
# results should not be interpreted as strong causal evidence.

iv_model <- feols(
  log_gdp_pc ~ education +
    urban +
    investment |
    country + year |
    internet ~ telephone_lag,
  data = data,
  vcov = ~country
)

summary(iv_model)

# Export regression table =================================================

modelsummary(
  list(
    "Exploratory IV" = iv_model
  ),
  coef_map = c(
    "fit_internet" = "Internet access (instrumented)",
    "education" = "Education",
    "urban" = "Urbanization",
    "investment" = "Investment"
  ),
  gof_map = tibble::tribble(
    ~raw,                ~clean,          ~fmt,
    "nobs",             "Observations", 0,
    "r.squared",        "R²",           3,
    "adj.r.squared",    "Adj. R²",      3,
    "within.r.squared", "Within R²",    3,
    "rmse",             "RMSE",         3
  ),
  add_rows = tibble::tribble(
    ~term,                    ~`Exploratory IV`,
    "Country FE",            "Yes",
    "Year FE",               "Yes",
    "IV",                    "Lagged fixed telephone subscriptions",
    "First-stage F-statistic", "353.8"
  ),
  stars = c(
    "***" = 0.001,
    "**" = 0.01,
    "*" = 0.05,
    "+" = 0.1
  ),
  notes = "Standard errors clustered at the country level are reported in parentheses.",
  output = file.path(
    tables_folder,
    "iv_regression_table.tex"
  )
)